const mongoose = require("mongoose")
const validator = require("validator")
const SHA256 = require("crypto-js/sha256")

var UserSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: true,
            unique: true,
            trim: true,
            validate: {
                validator: validator.isEmail,
                message: "email invalid"
            }
        },

        password: {
            type: String,
            required: true,
            trim: true
        },

        tokens: [
            {
                token: {
                    type: String,
                    required: false
                }
            }
        ]
    }
)

UserSchema.pre("save", function (next) {
    const user = this
    if (user.isModified("password")) {
        user.password = SHA256(user.password).toString()
    }
    next()
})

UserSchema.methods.valid = function (email, password) {
    const user = this
    return (
        this.email === email
        &&
        this.password === SHA256(password).toString()
    )
}

UserSchema.statics.findOneAndValid = function (email, password) {
    const User = this
    console.log(SHA256(password).toString())
    return User.findOne({
        email,
        password: SHA256(password).toString()
    }).then(user => {
        if (user) return user
        return Promise.reject("User not found.")
    })
}

UserSchema.methods.toJSON = function () {
    const user = this
    const {
        email
    } = user

    return {
        email
    }
}

module.exports = mongoose.model("User", UserSchema)
