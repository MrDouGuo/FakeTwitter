const express = require("express")
const bodyParser = require("body-parser")
const cors = require("cors")

const User = require("./models/User")

require("./db/mongoose")

var app = express()
app.use(bodyParser.json())
app.use(cors())

app.get("/", (req, res) => {
    res.send("Hello World.")
})

app.post("/newuser", async (req, res) => {
    const {
        email,
        password
    } = req.body

    const user = new User({
        email,
        password
    })


    await user.save().catch(err => {
        res.status(400).send(err)
    })

    res.send("OK")

})

app.get("/user/:email/:password", async (req, res) => {
    const {
        email,
        password
    } = req.params

    const user = await User.findOneAndValid(email, password).catch(err => {
        res.status(404).send(err)
    })

    res.send(user)
})

app.listen(3000)

