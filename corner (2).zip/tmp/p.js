const p = new Promise((resolve, reject) => {
    return resolve(1)
    console.log(2)
})

p.then(() => {
    throw "sdfgsdf"
}).catch(err => {
    console.log(err)
})

setTimeout(() => {
    console.log("something else")
}, 1000)