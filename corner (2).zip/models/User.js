const mongoose = require("mongoose")
const validator = require("validator")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const { salt } = process.env
const remove = require("lodash/remove")

var UserSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        minlength: 3
    },

    email: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        validate: {
            validator: validator.isEmail,
            message: "email invalid"
        }
    },

    password: {
        type: String,
        required: true,
        trim: true,
        minlength: 6
    },

    tokens: [
        {
            token: {
                type: String,
                required: true
            }
        }
    ]
})

UserSchema.pre("save", function (next) {
    const user = this
    if (user.isModified("password")) {
        bcrypt.genSalt(10, (err, salt) => {
            if (err) console.log(err)
            bcrypt.hash(user.password, salt, (err, hash) => {
                if (err) console.log(err)
                user.password = hash
                next()
            })
        })
    }
    next()
})

UserSchema.statics.validate = async function (account) {
    const {
        username,
        email,
        password
    } = account

    const User = this
    const info = {}
    if (username) info.username = username
    else if (email) info.email = email
    else return Promise.reject("info invalid")
    const user = await User.findOne(info).catch(err => {
        console.log(err)
    })
    if (!user) return Promise.reject("user not found")
    return bcrypt.compare(password, user.password) // boolean
}

UserSchema.statics.findByUsernameOrEmail = function(usernameOrEmail){
    const {username, email} = usernameOrEmail
    const User = this
    const info = {}
    if (username) info.username = username
    else if (email) info.email = email
    else return Promise.reject("info invalid")
    return User.findOne(info)
}

UserSchema.methods.generateToken = function () {
    const user = this
    const { username } = user
    const token = jwt.sign(
        { username },
        salt
    ).toString()
    user.tokens.push(
        { token }
    )
    return user.save().then(() => token)
}

const jwtVerify = token => new Promise((resolve, reject) => {
    jwt.verify(token, salt, (err, decoded) => {
        if (err) reject(err)
        else resolve(decoded)
    })
})

UserSchema.methods.verifyToken = function (token) {
    const user = this
    return jwtVerify(token).then(decoded => {
        const { username } = decoded
        if (user.username === username) {
            for (let e of user.tokens) {
                if (e.token === token) {
                    return username
                }
            }
            return Promise.reject("token expired")
        }
        return Promise.reject("token invalid")
    })
}

UserSchema.methods.removeToken = function (token) {
    const user = this
    return user.update({
        $pull: {
            tokens: {token}
        }
    })
}

UserSchema.statics.findByToken = function (token) {
    const User = this
    return jwtVerify(token).then(decoded => {
        const { username } = decoded
        return User.findOne({ username })
            .then(user => {
                if (!user) return Promise.reject("user not found")
                for (let e of user.tokens) {
                    if (e.token === token) {
                        return user
                    }
                }
                return Promise.reject("token expired")
            })
    })
}

UserSchema.methods.toJSON = function () {
    const { username, email } = this
    return { username, email }
}

module.exports = mongoose.model("User", UserSchema)
