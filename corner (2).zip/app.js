require("./config/config")
require("./db/mongoose")

const express = require("express")
const bodyParser = require("body-parser")
const cors = require("cors")

const User = require("./models/User")
const Info = require("./models/Info")
const Preference = require("./models/Preference")
const {
    Follower,
    Following
} = require("./models/Follower")
const Article = require("./models/Article")

const auth = require("./middleware/auth")

var app = express()
app.use(bodyParser.json())
app.use(cors())

app.post("/register", async (req, res) => {
    const { username, email, password } = req.body
    const user = new User({ username, email, password })
    try {
        // 1 user save
        const { _id } = await user.save()
        // 2 others
        const userid = _id
        const list = [Info, Preference, Follower, Following].map(E => (new E({ userid })).save())
        await Promise.all(list)
        // 3 token
        const token = await user.generateToken()
        res.header({ "x-auth": token }).send(user.toJSON())
    } catch (err) {
        res.status(400).send(err)
    }
})

app.post("/login", async (req, res) => {
    const { username, email, password } = req.body
    try {
        if (await User.validate({ username, email, password })) {
            const user = await User.findByUsernameOrEmail({ username, email })
            if (!user) res.status(400).send("user not found")
            const token = await user.generateToken()
            res.header({ "x-auth": token }).send(user.toJSON())
        }
        else res.status(400).send("auth failed")
    } catch (err) {
        res.status(400).send(err)
    }
})

app.delete("/logout", auth, async (req, res) => {
    const { token, user } = req
    await user.removeToken(token).catch(err => {
        res.status(400).send(err)
    })
    res.send("OK")
})

app.post("/article", auth, (req, res) => {
    const { user } = req
    const {
        text,
        media,
        parentid
    } = req.body

    media = media || ""
    parentid = parentid || null

    const article = new Article({
        userid: user._id,
        text,
        media,
        parentid
    })

    article.save()
        .then(() => {
            res.send("ok")
        })
        .catch(err => {
            res.status(400).send(err)
        })
})

app.get("/article/:articleid", (req, res) => {
    const { articleid } = req.params

    Article.findById(articleid)
        .then(article => {
            if (!article) res.status(404).send("article not found")
            else res.send(article.toObject())
        })

})

app.post("/like", auth, async (req, res) => {
    const { user } = req
    const { articleid } = req.body

    try {
        const article = await Article.findById(articleid)
        if (!article) res.status(404).send("article not found")
        else {
            if (article.liked.find(e => e.userid === user.id)) {
                await article.update({
                    $pull: {
                        liked: {
                            userid: user.id
                        }
                    }
                })
            }
            else {
                article.liked.push({ userid: user.id })
                await article.save()
            }
        }
        res.send("ok")
    } catch (err) {
        res.status(400).send(err)
    }
})

const findTree = async (articleid, tree) => {
    const article = await Article.findById(articleid)
    if (article) {
        tree.push(article.toObject)
        const children = await Article.find({ parentid: articleid })
        if (children.length) {
            await Promise.all(
                children.map(e => findTree(e))
            )
        }
    }
}

app.get("/articletree/:articleid", async (req, res) => {
    const { articleid } = req.params
    const tree = []
    try {
        await findTree(articleid, tree)
        res.send(tree)
    } catch (err) {
        res.status(400).send(err)
    }

})

app.delete("/article/:articleid", auth, (req, res) => {
    const { articleid } = req.params
    await Article.findByIdAndRemove(articleid)
        .catch(err => {
            res.status(400).send(err)
        })
    res.send("ok")
})

app.post("/follow", auth, async (req, res) => {
    const i = req.user
    const yourid = req.body.userid
    try {
        const myFollowing = await Following.findOne({ userid: i._id })
        const yourFollower = await Follower.findOne({ yourid })

        yourFollower.push({ userid: i.id })
        myFollowing.push({ userid: yourid })

        await myFollowing.save()
        await yourFollower.save()

        res.send("ok")
    } catch (err) {
        res.status(400).send(err)
    }
})

app.post("/defollow", auth, async (req, res) => {
    const i = req.user
    const yourid = req.body.userid
    try {
        const myFollowing = await Following.findOne({ userid: i._id })
        const yourFollower = await Follower.findOne({ yourid })

        await myFollowing.update({
            $pull: {
                list: {
                    userid: yourid
                }
            }
        })

        await yourFollower.update({
            $pull: {
                list: {
                    userid: i.id
                }
            }
        })

        res.send("ok")
    } catch (err) {
        res.status(400).send(err)
    }
})

app.get("/articles/:userid")

app.get("/followings/:userid")

app.get("/followers/:userid")

app.listen(3000)
