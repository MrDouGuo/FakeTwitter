const User = require("../models/User")

const auth = (req, res, next) => {
    const token = req.header("x-auth")
    User.findByToken(token)
        .then(user => {
            req.token = token
            req.user = user
            next()
        })
        .catch(err => {
            res.status(401).send(err)
        })
}

module.exports = auth
