require("./config/config")
require("./db/mongoose")

const express = require("express")
const bodyParser = require("body-parser")
const cors = require("cors")

const User = require("./models/User")
const Info = require("./models/Info")
const Preference = require("./models/Preference")
const {
    Follower,
    Following
} = require("./models/Follower")
const Article = require("./models/Article")

const auth = require("./middleware/auth")

var app = express()
app.use(bodyParser.json())
app.use(cors())

app.post("/register", async (req, res) => {
    const { username, email, password } = req.body
    const user = new User({ username, email, password })
    try {
        // 1 user save
        const { _id } = await user.save()
        // 2 others
        const userid = _id
        const list = [Info, Preference, Follower, Following].map(E => (new E({ userid })).save())
        await Promise.all(list)
        // 3 token
        const token = await user.generateToken()
        res.header({ "x-auth": token }).send(user.toJSON())
    } catch (err) {
        res.status(400).send(err)
    }
})

app.post("/login", async (req, res) => {
    const { username, email, password } = req.body
    try {
        if (await User.validate({ username, email, password })) {
            const user = await User.findByUsernameOrEmail({ username, email })
            if (!user) res.status(400).send("user not found")
            const token = await user.generateToken()
            res.header({ "x-auth": token }).send(user.toJSON())
        }
        else res.status(400).send("auth failed")
    } catch (err) {
        res.status(400).send(err)
    }
})

app.delete("/logout", auth, async (req, res) => {
    const {token, user} = req
    await user.removeToken(token).catch(err => {
        res.status(400).send(err)
    })
    res.send("OK")
})



app.listen(3000)
