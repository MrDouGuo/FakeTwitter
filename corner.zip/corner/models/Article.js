const mongoose = require("mongoose")
const validator = require("validator")

var ArticleSchema = new mongoose.Schema({
    userid: {
        type: mongoose.Types.ObjectId,
        required: true
    },

    text: {
        type: String,
        required: true,
        minlength: 1
    },

    media: {
        type: String,
        validate: {
            validator: validator.isURL
        }
    },

    liked: [
        {
            userid: {
                type: mongoose.Types.ObjectId,
                required: true
            }
        }
    ],

    parentid: {
        type: mongoose.Types.ObjectId
    }
})

module.exports = mongoose.model("Article", ArticleSchema)