const app = require("../app")
const request = require("supertest")

class TestUser {
    constructor(info) {
        this.info = info
    }

    register() {
        const { info } = this
        return new Promise((resolve, reject) => {
            request(app)
                .post("/register")
                .send(info)
                .end((err, res) => {
                    if(err) reject(err)
                    else {
                        resolve(res.header["x-auth"])
                    }
                })
        })
    }

    login() {
        const {info} = this
        return new Promise((resolve, reject) => {
            request(app)
                .post("/login")
                .send(info)
                .end((err, res) => {
                    if(err) reject(err)
                    else resolve(res.header["x-auth"])
                })
        })
    }

    logout(token){
        return new Promise((resolve, reject) => {
            request(app)
                .delete("/logout")
                .set("x-auth", token)
                .end((err, res) => {
                    if(err) reject(err)
                    else resolve()
                })
        })
    }

    get email(){
        return this.info.email
    }
}

module.exports = TestUser

