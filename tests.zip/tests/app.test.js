const chai = require("chai")
const {expect} = chai
const should = chai.should()
const request = require("supertest")

const app = require("../app")
const User = require("../models/User")

const TestUser = require("./TestUser")

const user1 = new TestUser({
    username: "one",
    email: "one@yinyan.fr",
    password: "123456"
})

const user2 = new TestUser({
    username: "two",
    email: "two@yinyan.fr",
    password: "12345678"
})

const removeTestUser = () => {
    return User.deleteMany({
        email: {
            $in: [
                user1.email,
                user2.email
            ]
        }
    })
}

beforeEach(removeTestUser)

describe("POST /register", () => {
    it("should register a user", async () => {
        const token = await user1.register()
        const user = await User.findOne({ email: user1.email })
        expect(user).to.exist
        for (let e of user.tokens) {
            if (e.token === token) {
                return 
            }
        }
        throw "token not registered"
    })

    it("should Not register a user twice", async () => {
        await user1.register()
        const twice = await user1.register()
        expect(twice).not.to.exist
        const users = await User.find({email: user1.email})
        expect(users).to.have.lengthOf(1)
    })
})

describe("POST /login", () => {
    it("should login and return a token", async () => {
        await user1.register()
        const token = await user1.login()
        const user = await User.findOne({ email: user1.email })
        expect(user).to.exist
        for (let e of user.tokens) {
            if (e.token === token) {
                return 
            }
        }
        throw "token not registered"
    })

    it("should Not login with a wrong password", async () => {
        await user1.register()

        request(app)
            .post("/login")
            .send({
                username: user1.username,
                email: user1.email,
                password: user2.password
            })
            .expect(400)
    })
})

describe("DELETE /logout", () => {
    it("should delete a token", async () => {
        const token = await user1.register()
        await user1.logout(token)
        const user = await User.findOne({email: user1.email})
        for (let e of user.tokens) {
            if (e.token === token) {
                throw "token not deleted" 
            }
        }
        return 
    })

    it("should reject an unauthorized request", async () => {
        await user1.register()
        request(app)
            .delete("/logout")
            .set("x-auth", "skdfsjdgfsjdkfb")
            .expect(401)
    })
})